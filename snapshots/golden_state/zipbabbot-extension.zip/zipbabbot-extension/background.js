// ZipbabBot Chrome Extension - Background Service Worker (Direct chrome.scripting Engine)
let isRunning = false;
let autoTabId = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'START_BATCH_ADD') {
    if (isRunning) return;
    isRunning = true;
    runBatchAdd(message.items, sender.tab ? sender.tab.id : null);
  } else if (message.action === 'STOP_BATCH_ADD') {
    isRunning = false;
  }
});

async function runBatchAdd(items, sourceTabId) {
  if (!items || items.length === 0) {
    isRunning = false;
    return;
  }

  // 1. Create automation tab (background or active window)
  try {
    const tab = await chrome.tabs.create({
      url: 'https://www.coupang.com',
      active: false
    });
    autoTabId = tab.id;
  } catch (err) {
    console.error('[ZipbabBot] Failed to create tab:', err);
    isRunning = false;
    return;
  }

  for (let i = 0; i < items.length; i++) {
    if (!isRunning) break;
    const item = items[i];

    // Report progress to dashboard tab
    sendProgress(sourceTabId, {
      type: 'ZIPBABBOT_PROGRESS',
      step: i + 1,
      total: items.length,
      item: item,
      status: 'SEARCHING'
    });

    const success = await processSingleItem(item, autoTabId);

    sendProgress(sourceTabId, {
      type: 'ZIPBABBOT_ITEM_DONE',
      index: (item.index !== undefined) ? item.index : i,
      query: item.query,
      success: success
    });

    // Cooldown between items
    if (i < items.length - 1 && isRunning) {
      await wait(1400);
    }
  }

  // Finished! Open Coupang Cart
  if (isRunning) {
    try {
      await chrome.tabs.update(autoTabId, {
        url: 'https://cart.coupang.com/cartView.pang',
        active: true
      });
    } catch(e) {}
    sendProgress(sourceTabId, {
      type: 'ZIPBABBOT_COMPLETE'
    });
  }

  isRunning = false;
}

async function processSingleItem(item, tabId) {
  try {
    // 1. Initial navigation (use direct link or Coupang search query)
    const initialUrl = item.url || `https://www.coupang.com/np/search?q=${encodeURIComponent(item.query)}&channel=user`;
    await chrome.tabs.update(tabId, { url: initialUrl });
    
    // Wait until tab completes loading and lands on www.coupang.com (handles link.coupang.com 302 redirects)
    let currentUrl = await waitForTabLoad(tabId, 8000);
    if (!currentUrl) {
      const tab = await chrome.tabs.get(tabId);
      currentUrl = tab.url || '';
    }

    // 2. If not on a product page, find best product link from search results
    if (!currentUrl.includes('/vp/products/')) {
      if (!currentUrl.includes('/np/search')) {
        const searchUrl = `https://www.coupang.com/np/search?q=${encodeURIComponent(item.query)}&channel=user`;
        await chrome.tabs.update(tabId, { url: searchUrl });
        await waitForTabLoad(tabId, 8000);
      }

      // Find best product link directly via chrome.scripting (retries up to 6 times)
      let targetProductUrl = null;
      for (let r = 0; r < 6; r++) {
        try {
          const results = await chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: (targetQty) => {
              const rawLinks = Array.from(document.querySelectorAll('a[href*="/vp/products/"]'));
              const links = rawLinks.filter(a => !a.href.includes('view_together') 
                          && !a.closest('.recently-viewed-item') 
                          && !a.closest('#recent-view') 
                          && (a.innerText || '').trim().length > 3);

              if (!links.length) return null;

              function scoreProduct(a) {
                const text = a.innerText;
                let score = 0;
                if (text.includes('박스') || text.includes('대용량') || text.includes('벌크') || text.includes('업소용') || text.includes('식자재')) score -= 1000;
                if (text.match(/([2-9]|[0-9]{2,}) *kg/) && !text.includes('쌀') && !text.includes('김치') && !text.includes('양파')) score -= 1200;
                const bulkMatch = text.match(/([4-9]|[0-9]{2,}) *(개|모|팩|봉|입|캔)/);
                if (bulkMatch && targetQty < 4) score -= 1000;

                if (targetQty === 1) {
                  if (text.match(/1 *(개|모|단|봉|팩|통|병|입|캔)/)) score += 500;
                  else if (text.match(/[23] *(개|모|단|봉|팩|구|입|캔)/)) score += 100;
                } else if (targetQty === 2) {
                  if (text.match(/2 *(개|모|단|봉|팩|통|병|입|캔)/)) score += 600;
                  else if (text.match(/1 *(개|모|단|봉|팩|통|병|입|캔)/)) score += 500;
                }

                if (text.includes('로켓프레시') || text.includes('새벽 도착') || text.includes('새벽도착')) score += 350;
                else if (text.includes('로켓배송') || text.includes('쿠팡추천')) score += 200;
                if (text.includes('광고')) score -= 200;
                return score;
              }

              const scored = links.map(a => ({ a: a, score: scoreProduct(a) }));
              scored.sort((x, y) => y.score - x.score);
              return scored[0].a.href;
            },
            args: [item.qty || 1]
          });

          if (results && results[0] && results[0].result) {
            targetProductUrl = results[0].result;
            break;
          }
        } catch(e) {}
        await wait(600);
      }

      if (targetProductUrl) {
        // Navigate directly to the real product detail page!
        await chrome.tabs.update(tabId, { url: targetProductUrl });
        await waitForTabLoad(tabId, 8000);
      } else {
        console.warn(`[ZipbabBot] Could not find product link for: ${item.name}`);
        return false;
      }
    }

    // 3. We are now on /vp/products/! Click add-to-cart button directly via chrome.scripting
    let clicked = false;
    for (let r = 0; r < 8; r++) {
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tabId },
          func: (targetQty) => {
            const titleEl = document.querySelector('h1.prod-buy-header__title, .prod-title, .title');
            const titleText = titleEl ? titleEl.innerText : '';
            let bundleSize = 1;
            const bundleMatch = titleText.match(/([2-9])\s*(개|모|팩|봉|입|캔|병|구)/);
            if (bundleMatch) {
              bundleSize = parseInt(bundleMatch[1], 10);
            }

            let finalQty = targetQty;
            if (bundleSize >= targetQty) finalQty = 1;
            else if (bundleSize > 1) finalQty = Math.max(1, Math.ceil(targetQty / bundleSize));

            // Adjust quantity input if needed
            const qtyInput = document.querySelector("input.prod-quantity__input, input.prod-buy-quantity");
            if (qtyInput && parseInt(qtyInput.value, 10) !== finalQty) {
              qtyInput.value = String(finalQty);
              qtyInput.dispatchEvent(new Event("input", { bubbles: true }));
              qtyInput.dispatchEvent(new Event("change", { bubbles: true }));
            }

            // Find button
            const btn = document.querySelector(".prod-cart-btn") || 
                        Array.from(document.querySelectorAll("button")).find(b => {
                          const t = (b.innerText || '').trim();
                          return t.includes("장바구니 담기") || t === "장바구니" || b.classList.contains("prod-cart-btn");
                        });

            if (btn && !btn.disabled) {
              btn.click();
              return true;
            }
            return false;
          },
          args: [item.qty || 1]
        });

        if (results && results[0] && results[0].result === true) {
          clicked = true;
          break;
        }
      } catch(e) {}
      await wait(600);
    }

    return clicked;
  } catch (err) {
    console.error(`[ZipbabBot] Error adding item ${item.name}:`, err);
    return false;
  }
}

function sendProgress(tabId, msg) {
  if (tabId) {
    chrome.tabs.sendMessage(tabId, msg).catch(() => {});
  }
}

function waitForTabLoad(tabId, maxWaitMs = 8000) {
  return new Promise((resolve) => {
    let resolved = false;
    const timeout = setTimeout(() => {
      if (!resolved) {
        resolved = true;
        chrome.tabs.onUpdated.removeListener(listener);
        chrome.tabs.get(tabId).then(t => resolve(t ? t.url : null)).catch(() => resolve(null));
      }
    }, maxWaitMs);

    const listener = (updatedTabId, changeInfo, tab) => {
      if (updatedTabId === tabId && changeInfo.status === 'complete') {
        if (!resolved) {
          resolved = true;
          clearTimeout(timeout);
          chrome.tabs.onUpdated.removeListener(listener);
          // Wait 800ms for dynamic React client-side rendering
          setTimeout(() => resolve(tab.url), 800);
        }
      }
    };

    chrome.tabs.onUpdated.addListener(listener);
  });
}

function wait(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
